#include "SpectrumAnalyzer.h"
#include <algorithm>
#include <cmath>

SpectrumAnalyzer::SpectrumAnalyzer(Vector2D size, Vector2D offset, bool bounce, bool flipY, bool mirrorY) {
    this->size = size.Divide(2.0f);
    this->offset = offset;
    this->mirrorY = mirrorY;
    this->flipY = flipY;
    this->bounce = bounce;
    this->material = &gM;

    if (bounce) {
        for (uint8_t i = 0; i < 128; i++) {
            bPhy[i] = new BouncePhysics(35.0f, 15.0f);
        }
    }
}

SpectrumAnalyzer::~SpectrumAnalyzer() {
    for (uint8_t i = 0; i < 128; i++) {
        delete bPhy[i];
    }
}

void SpectrumAnalyzer::SetMirrorYState(bool state) {
    mirrorY = state;
}

void SpectrumAnalyzer::SetFlipYState(bool state) {
    flipY = state;
}

void SpectrumAnalyzer::SetMaterial(Material* material) {
    this->material = material;
}

float* SpectrumAnalyzer::GetFourierData() {
    return bounce ? bounceData : data;
}

void SpectrumAnalyzer::SetSize(Vector2D size) {
    this->size = size.Divide(2.0f);
}

void SpectrumAnalyzer::SetPosition(Vector2D offset) {
    this->offset = offset;
}

void SpectrumAnalyzer::SetRotation(float angle) {
    this->angle = angle;
}

void SpectrumAnalyzer::SetHueAngle(float hueAngle) {
    this->hueAngle = hueAngle;
}

void SpectrumAnalyzer::EnablePeakHoldBlend(bool enable, float blendRatio) {
    usePeakHoldBlend = enable;
    if (enable) {
        peakHoldBlend = Mathematics::Constrain(blendRatio, 0.0f, 1.0f);
    }
}

void SpectrumAnalyzer::SetSmoothingRadius(uint8_t radius) {
    if (radius > 2) radius = 2;
    smoothingRadius = radius;
}

void SpectrumAnalyzer::EnableFrequencyRemap(bool enable, float exponent) {
    frequencyRemapEnabled = enable;
    if (enable) {
        if (exponent < 0.2f) exponent = 0.2f;
        if (exponent > 3.0f) exponent = 3.0f;
        frequencyRemapExponent = exponent;
    }
}

void SpectrumAnalyzer::EnableColumnInterpolation(bool enable) {
    interpolateColumns = enable;
}

void SpectrumAnalyzer::Update(float* readData) {
    if (!readData) {
        data = processedData;
        visualReady = false;
        return;
    }

    constexpr float emphasisSlope = 0.22f;
    constexpr float lowBinBoost = 1.18f;
    constexpr float riseCoeff = 0.58f;
    constexpr float fallCoeff = 0.18f;
    constexpr float peakFall = 0.90f;
    constexpr uint8_t peakHoldFrames = 14;
    constexpr float holdTolerance = 0.008f;

    float peak = 0.0f;
    float noiseAccumulator = 0.0f;
    float lowBandEnergy = 0.0f;

    for (uint8_t i = 0; i < bins; ++i) {
        float value;
        if (frequencyRemapEnabled) {
            float normalized = float(i) / float(bins - 1);
            float curved = powf(normalized, frequencyRemapExponent);
            float srcIndex = curved * float(bins - 1);
            uint8_t left = uint8_t(srcIndex);
            uint8_t right = left < bins - 1 ? left + 1 : left;
            float frac = srcIndex - float(left);
            value = Mathematics::CosineInterpolation(readData[left], readData[right], frac);
        } else {
            value = Mathematics::Constrain(readData[i], 0.0f, 1.0f);
        }
        value = Mathematics::Constrain(value, 0.0f, 1.2f);
        float emphasis = 0.85f + (float(i) / float(bins - 1)) * emphasisSlope;
        if (i < 6) emphasis *= lowBinBoost;
        value = Mathematics::Constrain(value * emphasis, 0.0f, 1.2f);
        noiseAccumulator += value;

        float previous = smoothedData[i];
        float coeff = (value > previous) ? riseCoeff : fallCoeff;
        float smooth = previous + (value - previous) * coeff;
        smoothedData[i] = smooth;

        if (smooth + holdTolerance >= peakHoldData[i]) {
            peakHoldData[i] = smooth;
            peakHoldTimer[i] = peakHoldFrames;
        } else if (peakHoldTimer[i] > 0) {
            peakHoldTimer[i]--;
        } else {
            peakHoldData[i] *= peakFall;
            if (peakHoldData[i] < 0.001f) peakHoldData[i] = 0.0f;
        }

        float displayValue = smooth;
        if (usePeakHoldBlend) {
            displayValue = smooth * (1.0f - peakHoldBlend) + peakHoldData[i] * peakHoldBlend;
        }

        processedData[i] = displayValue;
        if (displayValue > peak) peak = displayValue;

        if (i < 24) {
            lowBandEnergy += displayValue;
        }
    }

    noiseAccumulator /= float(bins);
    noiseFloor = noiseFloor * 0.9f + noiseAccumulator * 0.1f;
    float floorClamp = Mathematics::Constrain(noiseFloor * 1.05f, 0.01f, 0.08f);

    constexpr float peakTarget = 0.9f;
    bool quiet = peak < floorClamp * 2.2f;
    idleFrames = quiet ? uint8_t(std::min<int>(idleFrames + 1, 90)) : 0;

    if (peak > 0.005f) {
        float desiredGain = peakTarget / peak;
        desiredGain = Mathematics::Constrain(desiredGain, 0.6f, 2.2f);
        float response = desiredGain > autoGain ? 0.20f : 0.08f;
        autoGain += (desiredGain - autoGain) * response;
    } else {
        autoGain += (1.0f - autoGain) * 0.06f;
    }

    float suppression = floorClamp * 1.85f;
    if (suppression < 0.010f) suppression = 0.010f;
    if (suppression > 0.20f) suppression = 0.20f;
    float baselineFloor = Mathematics::Constrain(floorClamp * 0.30f, 0.004f, 0.020f);
    for (uint8_t i = 0; i < bins; ++i) {
        float value = processedData[i];
        if (value <= suppression) {
            float quietRatio = suppression > 0.0f ? (value / suppression) : 0.0f;
            processedData[i] = baselineFloor * (0.5f + quietRatio * 0.5f);
            continue;
        }

        // Normalize after gating to preserve isolated spikes above the noise floor.
        value = (value - suppression) / (1.0f - suppression);
        value = Mathematics::Constrain(value * autoGain, 0.0f, 1.1f);
        processedData[i] = powf(value, 0.90f);
        if (processedData[i] < baselineFloor) processedData[i] = baselineFloor;
    }

    if (quiet && idleFrames > 18) {
        float quietDecay = idleFrames > 45 ? 0.75f : 0.85f;
        for (uint8_t i = 0; i < bins; ++i) {
            peakHoldTimer[i] = 0;
            peakHoldData[i] *= quietDecay;
            smoothedData[i] *= quietDecay;
            float displayValue = usePeakHoldBlend
                                     ? smoothedData[i] * (1.0f - peakHoldBlend) + peakHoldData[i] * peakHoldBlend
                                     : smoothedData[i];
            processedData[i] = displayValue;
            if (processedData[i] < baselineFloor) processedData[i] = baselineFloor;
        }
        visualReady = false;
    }

    lowBandEnergy = (lowBandEnergy / 24.0f);
    bassEnvelope = bassEnvelope * 0.88f + lowBandEnergy * 0.12f;
    float beatDelta = Mathematics::Max(0.0f, lowBandEnergy - bassEnvelope);
    beatPulse = Mathematics::Constrain(beatPulse * 0.85f + beatDelta * 2.4f, 0.0f, 1.0f);
    beatHueOffset = beatHueOffset * 0.9f + beatDelta * 60.0f;

    const float* source = processedData;
    if (bounce) {
        for (uint8_t i = 0; i < bins; ++i) {
            bounceData[i] = bPhy[i]->Calculate(processedData[i], 0.1f);
        }
        data = bounceData;
        source = bounceData;
    } else {
        data = processedData;
    }

    BuildVisualData(source);
}

RGBColor SpectrumAnalyzer::GetRGB(const Vector3D& position, const Vector3D& normal, const Vector3D& uvw) {
    Vector2D rPos = Mathematics::IsClose(angle, 0.0f, 0.1f)
                        ? Vector2D(position.X, position.Y) - offset
                        : Vector2D(position.X, position.Y).Rotate(angle, offset) - offset;

    const float* renderData = visualReady ? visualData : data;
    if (renderData == nullptr) return RGBColor();

    if (rPos.X < -size.X || rPos.X > size.X) return RGBColor();
    if (rPos.Y < -size.Y || rPos.Y > size.Y) return RGBColor();

    float mapped = Mathematics::Map(rPos.X, -size.X, size.X, 0.0f, float(bins - 1));
    if (mapped < 0.0f) mapped = 0.0f;
    float maxIndex = float(bins - 1);
    if (mapped > maxIndex) mapped = maxIndex;

    float height = SampleFrequency(mapped);
    height = Mathematics::Constrain(height * 2.8f, 0.0f, 1.0f);
    float yColor;

    if (mirrorY) {
        yColor = Mathematics::Map(fabsf(rPos.Y), size.Y, 0.0f, 1.0f, 0.0f);
    } else {
        yColor = Mathematics::Map(rPos.Y, -size.Y, size.Y, 1.0f, 0.0f);
    }

    if (flipY) yColor = 1.0f - yColor;

    if (yColor <= height) {
        float dynamicHue = hueAngle + beatHueOffset;
        return material->GetRGB(Vector3D(1.0f - height - yColor, 0, 0), Vector3D(), Vector3D()).HueShift(dynamicHue);
    } else {
        return RGBColor(0, 0, 0);
    }
}

void SpectrumAnalyzer::BuildVisualData(const float* source) {
    if (!source) {
        visualReady = false;
        return;
    }

    if (smoothingRadius == 0) {
        for (uint8_t i = 0; i < bins; ++i) {
            visualData[i] = source[i];
        }
    } else if (smoothingRadius == 1) {
        constexpr float kernel[3] = {0.2f, 0.6f, 0.2f};
        constexpr int radius = 1;
        for (uint8_t i = 0; i < bins; ++i) {
            float sum = 0.0f;
            for (int k = -radius; k <= radius; ++k) {
                int idx = int(i) + k;
                if (idx < 0) idx = 0;
                if (idx >= bins) idx = bins - 1;
                sum += source[idx] * kernel[k + radius];
            }
            visualData[i] = sum;
        }
    } else {
        constexpr float kernel[5] = {0.08f, 0.2f, 0.44f, 0.2f, 0.08f};
        constexpr int radius = 2;
        for (uint8_t i = 0; i < bins; ++i) {
            float sum = 0.0f;
            for (int k = -radius; k <= radius; ++k) {
                int idx = int(i) + k;
                if (idx < 0) idx = 0;
                if (idx >= bins) idx = bins - 1;
                sum += source[idx] * kernel[k + radius];
            }
            visualData[i] = sum;
        }
    }

    visualReady = true;
}

float SpectrumAnalyzer::SampleFrequency(float index) const {
    const float* source = visualReady ? visualData : (bounce ? bounceData : data);
    if (source == nullptr) return 0.0f;

    float maxIndex = float(bins - 1);
    if (index < 0.0f) index = 0.0f;
    if (index > maxIndex) index = maxIndex;

    if (!interpolateColumns) {
        uint8_t idx = uint8_t(index + 0.5f);
        if (idx >= bins) idx = bins - 1;
        return source[idx];
    }

    uint8_t left = uint8_t(index);
    uint8_t right = left < bins - 1 ? left + 1 : left;
    float frac = index - float(left);
    return Mathematics::CosineInterpolation(source[left], source[right], frac);
}
