#include "RainbowNoise.h"

void RainbowNoise::Update(float ratio) {
    float sweep = fGenMatGradient.Update();
    float sShift = sweep * 0.004f + 0.005f;

    simplexNoiseDepth += 0.001f;

    gNoiseMat.SetGradientPeriod(0.5f + sweep * 12.0f);
    gNoiseMat.HueShift(ratio * 360 * 2);
    sNoise.SetScale(Vector3D(sShift, sShift, sShift));
    sNoise.SetZPosition(simplexNoiseDepth);
}

Material* RainbowNoise::GetMaterial() {
    return &sNoise;
}

RGBColor RainbowNoise::GetRGB(const Vector3D& position, const Vector3D& normal, const Vector3D& uvw) {
    return sNoise.GetRGB(position, normal, uvw);
}
