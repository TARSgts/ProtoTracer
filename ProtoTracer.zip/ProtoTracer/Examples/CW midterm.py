#Carson Werner
#Midterm 1

#Answer 1

def harmonic_series(i):
    if i == 1:
        return 1
    else:
        return 1/i + harmonic_series(i-1)

#Test cases  
  
print(harmonic_series(5))
print(harmonic_series(10))
print(harmonic_series(100))

#Answer 2

def count_obstacles(scan):
    count = 0
    
    for value in scan:
        if value == 1:
            count += 1 
    return count

#Test cases

print(count_obstacles([0, 1, 0, 0, 1, 1,1]))
print(count_obstacles([0, 0, 0, 0, 0]))
print(count_obstacles([1, 1, 1, 1, 1]))

#Answer 3

class buildMatrix:
    def __init__(self, rows, columns, data):
        self.rows = rows
        self.columns = columns
        self.data = data 
    
    def get_element(self, row, column):
        return self.data[row][column]
    
    def set_element(self, row, column, value):
        self.data[row][column] = value

#Test cases
matrix = buildMatrix(2, 2, [[1, 2], [3, 5]])
print(matrix.get_element(0, 1))
matrix.set_element(1, 1, 10)
print(matrix.data)

matrix2 = buildMatrix(3, 3, [[1, 2, 3], [4, 5, 6], [7, 8, 9]])
print(matrix2.get_element(2, 0))
matrix2.set_element(0, 0, 0)
print(matrix2.data)

#Answer 4

class squareMatrix(buildMatrix):
    def __init__(self, rows, columns, data):
        
        if rows != columns:
            raise ValueError("Rows and columns are not equal.")
        
        super().__init__(rows, columns, data)

#Test cases

squareMatrix1 = squareMatrix(2, 2, [[1, 2], [3, 4]])
print(squareMatrix1.get_element(0, 1))
squareMatrix1.set_element(1, 0, 10)
print(squareMatrix1.data)